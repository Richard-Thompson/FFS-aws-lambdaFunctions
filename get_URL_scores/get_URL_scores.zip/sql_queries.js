const getUrlAndScore = `SELECT * FROM base_urls`;

module.exports={
  getUrlAndScore: getUrlAndScore
};