const bluebird = require('bluebird');
const pgp = require('pg-promise')({ promiseLib: bluebird });
const dbCredentials = {
    user: process.env.user,
    password: process.env.password,
    host: process.env.host,
    port: process.env.port,
    database: process.env.database
};
const db = pgp(dbCredentials);

const query = require('./sql_queries');

exports.handler = (event, context, callback) => {
    const comment = require('querystring').parse(event.body.comment);
    const articleId = require('querystring').parse(event.body.articleId);
    const userId = require('querystring').parse(event.body.userId);
    const connectingCommentId = require('querystring').parse(event.body.connectingCommentId);
    context.callbackWaitsForEmptyEventLoop = false;
    let query = 'INSERT INTO comments (comment, article_id, user_id, connecting_comment_id) VALUES ($1,$2,$3,$4)';
    db.query(query, [comment,articleId, userId, connectingCommentId])
      .then(function (rows) {
        let response = {
          statusCode: '201',
          body: JSON.stringify({rows: rows}),
          headers: {
          'Content-Type': 'application/json',
        }
       };

    context.succeed(response);
           
      })
      .catch(function (error) {
        return callback(error);
      });
    
 };